# Sample-Zoo-Database
Zoo Database written in SQL w/ Simple Sample Queries
----

This is a simple Zoo Database written in SQL designed for use with mysql.

This example was designed as one part of a semester project in a course at the University of Central Florida.
